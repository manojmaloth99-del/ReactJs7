
import React, { useState, useEffect } from 'react';
import './UserList.css';

export default function UserList() {

    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");

    
    const fetchUsers = () => {

        setLoading(true);
        setError("");

        fetch("https://jsonplaceholder.typicode.com/users")

            .then((response) => {
                if (!response.ok) {
                    throw new Error("Failed to fetch user data");
                }

                return response.json();
            })

            .then((data) => {
                setUsers(data);
                setLoading(false);
            })

            .catch((err) => {
                setError(err.message);
                setLoading(false);
            });
    };

    
    useEffect(() => {
        fetchUsers();
    }, []);

    
    if (loading) {
        return (
            <div className="status">
                <h2>Loading Users...</h2>
            </div>
        );
    }
    
    if (error) {
        return (
            <div className="status">
                <h2>{error}</h2>
                <button onClick={fetchUsers}>
                    Try Again
                </button>
            </div>
        );
    }

    return (
        <div className="user-container">

            <h1>User Management Dashboard</h1>

            <p className="subtitle">
                API Integration using React useEffect
            </p>

            <button
                className="refresh-btn"
                onClick={fetchUsers}
            >
                Refresh Users
            </button>

            <div className="table-container">

                <table>

                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Website</th>
                        </tr>
                    </thead>

                    <tbody>
                        {users.map((user) => (
                            <tr key={user.id}>
                                <td>{user.id}</td>
                                <td>{user.name}</td>
                                <td>{user.username}</td>
                                <td>{user.email}</td>
                                <td>{user.phone}</td>
                                <td>{user.website}</td>
                            </tr>
                        ))}
                    </tbody>

                </table>

            </div>

            <h3 className="total-users">
                Total Users: {users.length}
            </h3>

        </div>
    );
}
