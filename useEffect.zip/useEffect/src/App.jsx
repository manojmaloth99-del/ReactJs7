
import React from 'react';
import UserList from './UserList';
import './App.css';

export default function App() {
    return (
        <div>
            <UserList />
            
        </div>
    );
}
