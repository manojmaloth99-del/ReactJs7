import React,{useEffect, useState} from 'react'

export default function Timer() {
    const[sec, setSec] = useState(0)
    const[Running, setRunning] = useState(false)

    useEffect(()=>{
        let intervalId;
        if(Running){
            intervalId = setInterval(()=>{
                setSec((prev)=> prev+1)
            },500)
        }
        return ()=> clearInterval(intervalId)
    },[Running])

    const handleStart = () =>{
        setRunning(true)
    }
    const handleStop = () =>{
        setRunning(false)
    }
    const handleRestart = () =>{
        setSec(0)
        setRunning(false)
    }
  return (
    <div>
        <h1>Timer:{sec}</h1>
        <button onClick={handleStart}>Start</button>
        <button onClick={handleStop}>Stop</button>
        <button onClick={handleRestart}>Reset</button>
    </div>
  )
}
