import React, { useState , useEffect} from 'react'

export default function UseEffectWithsetTimeOut() {
    const[message, setMessage] = useState("Please....wait")
    useEffect(()=>{
        const timer = setTimeout(()=>{
            setMessage("Hello welcome to the react js")
        }, 3000);
        return()=>clearTimeout(timer)
    },[])
  return (
    <div>
        <h2>{message}</h2>
    </div>
  )
}
