import React, { useEffect } from 'react'
import { useState } from 'react'

export default function UseeFetchApi() {
    const[user, setUser] = useState([])
    const[loading, setLoading] = useState(true)

    useEffect(()=>{
        fetch("https://jsonplaceholder.typicode.com/users")
        .then((res)=>res.json())
        .then((data)=>{
            setUser(data)
        })
    },[])
  return (
    <div>
        <h1>useEffect hook API</h1>
        {user.map((person)=>
        <div key={person.id}>
            
            <h3>name:{person.name}</h3>
            <h3></h3>
        </div>
        )}
    </div>
  )
}
